/*! OTemplate js-1.0.1 Ocaola*/
(function () {
	'use strict';
/*
	--> keywords: OTPL

	--> variables, expression, script must be between <% and %>
	--> tabulation, space,LF, CRLF... before <% and after %> are removed
	--> variable name must be declared with @var $my_var_name
	--> variable name must start with $ as in php
	--> e.g: @var $my_var_name
	
	--> tabulation and new line must be escaped like \\t and \\n

	--> if data = { age:23, nom:'toto' }
		-access to age : $.age, $['age'] or $.age
		-access to nom : $.nom, $['nom'] or $.nom

	--> if data = [23,'toto']
		-access to 23 : $[0]
		-access to 'toto' : $[1]
*/

	var TEMP_STORE = {};
	var OTPL_SAMPLE_FILE = "//__URL__\n(function(){\n\t'use strict';\n\twindow.OTplCompiled = window.OTplCompiled || {};\n\twindow.OTplCompiled['__FUNC_NAME__'] = function(data){\n\t\tvar arg = {'out':[],'data':data};\n\n\t\treturn (function(ROOT){__OUTPUT__})(arg);\n\t};\n})();\n\n";

	var OTplCompiled = {};
	var OTplUtils = {
		importExec: function(url,data){
			var otpl = OTplCompiled[url];
			if (otpl instanceof OTemplate) return otpl.runWith(data);
			else if (typeof otpl === 'function') return otpl(data);
			else throw "OTemplate:: '"+url+"' is requiered as dependance";
		},
		loadFile: function(url) {
			if ( !(url in TEMP_STORE) ){
				var xhr = new XMLHttpRequest();
				xhr.open("GET", url,false);//<-- synchrone
				xhr.send(null);

				if (xhr.status === 0 || (xhr.status >= 200 && xhr.status < 300)) {
					TEMP_STORE[url] = xhr.responseText;
				} else {
					throw "OTemplate:: can't read file at url : "+url+" status : " + xhr.status;
				}
			}

			return TEMP_STORE[url];
		},
		textToLineString: function(txt) {
			return txt.replace(/"/g, '\\"')
					.replace(/\t/g, '\\t')
					.replace(/\n/g, '\\n')
					.replace(/\r/g, '\\r');
		}
	};

	var OTplPlugins = {
		HtmlUtilsSetAttr:function(key,val){
			var _ = " ",
				data = {};

			if (typeof key === 'string'){
				data[key] = val;
			} else {
				data = arguments[0];
			}

			for(var attr in data){
				_ += attr + '="' + data[attr]+'" ';
			}
			return _;
		}
	};

	var OTemplate = function (parent_dep) {
		var m					= this,
		OTPL_TAG_REG			= /<%(.+?)?%>/g,
		OTPL_SCRIPT_REG			= /^(\s*)?(if|else|for|while|break|continue|switch|case|default|})/,
		OTPL_TYPE_EXPRESSION	= 0,
		OTPL_TYPE_SCRIPT		= 1,

		OTPL_REPLACE			= [
			//@var => var
			{
				reg: /@var/g,
				val: 'var'
			},
			//$$ 		--> ROOT.data
			{
				reg: /[$]{2}(\W)/g,
				val: 'ROOT.data$1'
			},
			//$.age		--> ROOT.data['age']
			{
				reg: /\$\.(\w+)/g,
				val: "ROOT.data['$1']"
			},
			//$['age']	--> ROOT.data['age']
			{
				reg: /\$\[(.*?)\]/g,
				val: 'ROOT.data[$1]'
			},
			//Ex: @import(url,data) --> OTplUtils.importExec(url,data)
			{
				reg: /@import\([\s]*?(?:'|\")(.*?)(?:'|\")(?:[\s]*,[\s]*(.+?)[\s]*)?[\s]*\)/g,
				val: function(){
					var url = arguments[1];
					var data = arguments[2];
					if (/\.otpl$/.test(url)){
						var obj = (new OTemplate()).parse(url,true);
						var deps = obj.dependancies;
							deps.push(url);

						for(var i = 0; i<deps.length; i++){
							var dep = deps[i];
							if( m.dependancies.indexOf(dep) < 0 ){
								m.dependancies.push(dep);
							}
						}

						return	"OTplUtils.importExec('"+url+"',"+data+")";
					} else {
						return "OTplUtils.loadFile('"+url+"')";
					}
				}
			},
			//@fn(...) --> OTplPlugins.fn(...)
			{
				reg: /@(\w+)/g,
				val: 'OTplPlugins.$1'
			},
			//foreach ( $obj as $key=>$val){ --> for ($key in $obj) { var $val = $obj[$key]; 
			{
				reg: /foreach[\s]*\([\s]*(.*?)[\s]+(?:as)[\s]+(.+?)[\s]*=>[\s]*(.+?)[\s]*\)[\s]*\{/g,
				val: 'for ($2 in $1) { var $3 = $1[$2]; '
			}
		];

		this.dependancies = [];

		this.RunVarReplace = function(source){

			for (var i = 0; i < OTPL_REPLACE.length; i++) {
				var rule = OTPL_REPLACE[i];
				source = source.replace(rule['reg'],rule['val']);
			}

			return source;
		};

		this.Engine = function (tpl) {
			var code = "\n",
			cursor = 0, found;

			var Add = function (line, type) {
				if (line != '') {
					switch (type) {
						case OTPL_TYPE_EXPRESSION:
							code += 'ROOT.out.push(' + line + ');\n';
							break;
						case OTPL_TYPE_SCRIPT:
							code += line + '\n';
							break;
						default:
							line = OTplUtils.textToLineString(line);
							code += 'ROOT.out.push("' + line + '");\n';
					}
				}
			};

			while (found = OTPL_TAG_REG.exec(tpl)) {

				var source = m.RunVarReplace(found[1]);

				Add(tpl.slice(cursor, found.index));

				if (OTPL_SCRIPT_REG.test(source)) {
					Add(source, OTPL_TYPE_SCRIPT);
				} else {
					Add(source, OTPL_TYPE_EXPRESSION);
				}

				cursor = found.index + found[0].length;
			}

			Add(tpl.substr(cursor, tpl.length - cursor));

			code += 'return ROOT.out.join("");';

			return code;
		};
	};

	OTemplate.prototype = {
		func_name:'',
		url:'inline.template.otpl',
		output:function(){ return "";},
		parse: function(tpl,isUrl){
			if (isUrl){
				var obj = OTplCompiled[tpl];
				if (obj instanceof OTemplate){
					this.output = obj.getOutput();
				} else {
					this.output = this.Engine(OTplUtils.loadFile(tpl));
				}

				this.func_name = this.url = tpl;
				OTplCompiled[tpl] = this;
			} else {
				this.output = this.Engine(tpl);
				this.func_name = (new Date()).getTime() +'_'+ Math.random();
			}

			return this;
		},
		getOutput: function () {
			return this.output;
		},
		runWith: function (data){
			return (new Function('ROOT',this.output))({out:[],data:data});
		},
		getFnString: function(){
			var fnstr = OTPL_SAMPLE_FILE
				.replace('__FUNC_NAME__',this.func_name)
				.replace('__OUTPUT__',this.getOutput())
				.replace('__URL__',this.url);

			return fnstr;
		},
		'export':function(fname) {
			var file_content = "/*! OTemplate "+OTemplate.OTPL_VERSION+" Ocaola*/\n";

			for(var i = 0; i < this.dependancies.length; i++){
				var dep = this.dependancies[i];
				var depObj = OTplCompiled[dep];
				file_content += depObj.getFnString() + "\n";
			}

			file_content += this.getFnString();

			var b = new Blob([file_content],{type:'application/x-javascript'});

			return URL.createObjectURL(new File([b],fname));
		}
	};

	OTemplate.OTPL_VERSION		= "js-1.0.1";
	OTemplate.OTPL_VERSION_NAME	= "OTemplate js-1.0.1";

	window.OTemplate			= OTemplate;
	window.OTplUtils			= OTplUtils;
	window.OTplPlugins			= OTplPlugins;
	window.OTplCompiled			= OTplCompiled;
})();