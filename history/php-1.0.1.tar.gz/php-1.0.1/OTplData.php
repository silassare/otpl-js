<?php

final class OTplData
{
	public $data = null;

	public function __construct($data)
	{
		$this->data = $data;
	}
}