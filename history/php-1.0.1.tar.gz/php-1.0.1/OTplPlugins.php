<?php

final class OTplPlugins
{
	public static function HtmlUtilsSetAttr($data){
		$attr = "";

		foreach($data as $key=>$val)
		{
			$attr .= " $key='$val' ";
		}

		return $attr;
	}
}