<?php

define('OTPL_DIR_ROOT', __DIR__ . DIRECTORY_SEPARATOR);

require_once OTPL_DIR_ROOT . 'OPathResolver.php';
require_once OTPL_DIR_ROOT . 'OTplUtils.php';
require_once OTPL_DIR_ROOT . 'OTplPlugins.php';
require_once OTPL_DIR_ROOT . 'OTplData.php';

final class OTpl
{
	const OTPL_VERSION						= "php-1.0.1";
	const OTPL_VERSION_NAME					= "OTpl php-1.0.1";

	const OTPL_COMPILE_DIR_NAME				= "otpl_done";

	private static $OTPL_TAG_REG			= "#<%(.+?)?%>#";
	private static $OTPL_SCRIPT_REG			= "#^(\s*)?(if|else|for|foreach|while|break|continue|switch|case|default|})#";
	private static $OTPL_STR_KEY_NAME_REG	= "#^[a-z_][a-z0-9_]+$#i";

	//SILO:: otpl_root_data alias $$ replacement
	private static $OTPL_ROOT_ALIAS_REG		= "#[$]{2}(\W)#";
	//SILO:: @import(url [,data]) replacement
	private static $OTPL_IMPORT_REG			= "#@import\([\s]*?(?:'|\")(.*?)(?:'|\")(?:[\s]*,[\s]*(.+?)[\s]*)?[\s]*\)#";
	private static $OTPL_FILE_EXT			= "#\.otpl$#";


	private static $OTPL_PLUGINS_OBJ_REF	= "OTplPlugins::";
	private $otpl_root_ref					= "\$otpl_root";
	private $otpl_root_data_ref				= "\$otpl_root->data";

	private static $OTPL_REPLACE			= array(
												"#([$]|\])\.(\w+)#",
												"#([$])\[(.+?)\]#"
											);

	private $src_path						= "";
	private	$dest_path						= "";
	private $compile_time					= 0;
	private	$func_name						= "otpl_nope_";
	private	$data_key						= null;
	private $input							= "";
	private $output							= null;

	private static $otpl_root = array();

	public function __construct(){}

	public function export($dest)
	{
		if (file_exists( $dest ) )
		{
			unlink($dest);
		}

		copy($this->dest_path,$dest);

		return $this;
	}

	private function save($dest = null)
	{
		$dest = $this->dest_path;

		$code = OTplUtils::loadFile( OTPL_DIR_ROOT ."output.php.sample");
		$code = str_replace(array(
					'{otpl_version}',
					'{otpl_version_name}',
					'{otpl_src_path}',
					'{otpl_compile_time}',
					'{otpl_func_name}',
					'{otpl_data_key}',
					'{otpl_root_ref_arg}',
					'{otpl_file_content}'
				),array(
					self::OTPL_VERSION,
					self::OTPL_VERSION_NAME,
					$this->src_path,
					$this->compile_time,
					$this->func_name,
					$this->data_key,
					$this->otpl_root_ref,
					$this->output
				), $code );

		$this->_write_file($dest,$code);

		return $this;
	}

	private function _write_file($path,$content){
		$f = fopen($path,'w');//SILO:: make sure that file is writeable,
		fwrite($f,$content);
		fclose($f);
	}

	public function parse($tpl,$isUrl,$force_new_compile = false)
	{
		$rand_str = "";
		$dest_dir = "./";
		$fname_prefixe  = "otpl_";
		$DS = DIRECTORY_SEPARATOR;

		if ($isUrl)
		{
			$this->input = OTplUtils::loadFile($tpl);
			$this->src_path = $tpl;
			$rand_str = md5_file($tpl);

			$finfos = pathinfo($tpl);
			$dest_dir = $finfos['dirname'];
			$fname_prefixe = $finfos['filename']; 
		} else {
			$this->input = $tpl;
			$rand_str = md5($tpl);
		}

		$this->output = $this->Engine();
		$dest_dir .= $DS . self::OTPL_COMPILE_DIR_NAME;
		$this->dest_path = $dest_dir . $DS . $fname_prefixe . '_' . $rand_str . '.php';

		if ( !file_exists( $dest_dir ) )
		{
			mkdir( $dest_dir, 0777 );
		}

		$this->func_name = "otpl_executor_$rand_str";
		$this->data_key = $rand_str;

		if ( !file_exists($this->dest_path) OR $force_new_compile )
		{
			$this->output = $this->Engine();
			$this->save();
		}

		return $this;
	}

	public function getOutputUrl()
	{
		return $this->dest_path;
	}

	public static function setExecData($key,$data)
	{
		self::$otpl_root[$key] = new OTplData($data);
	}

	public function getDataKey()
	{
		return $this->data_key;
	}

	public function getFuncName()
	{
		return $this->func_name;
	}

	public function runWith($data)
	{
		self::setExecData($this->data_key,$data);
		require_once $this->dest_path;
	}

	public function runSave($data,$out_url){
		$out_url = OPathResolver::resolve(__DIR__,$out_url);
		ob_start();
			$this->runWith($data);
			$content = ob_get_contents();
		ob_get_clean();

		$this->_write_file($out_url,$content);
	}

	public static function register($compile_descriptions)
	{
		$func_name = $compile_descriptions['func_name'];
		$data_key = $compile_descriptions['data_key'];

		if ( is_callable($func_name) )
		{
			//SILO::
				//on verifie s'il s'agit du template principale
				//si oui on execute
				//si non alors il s'agit d'une dependence/inclusion
			if (isset(self::$otpl_root[$data_key]))
			{
				call_user_func($func_name,self::$otpl_root[$data_key]);
				return true;
			}
		}

		return false;
	}

	private function Engine()
	{
		$tpl = $this->input;

		$in = array();

		while( preg_match(self::$OTPL_TAG_REG,$tpl,$in) )
		{
			@list($found,$content) = $in;
			$result = $this->process($content);
			$tpl = str_replace($found,$result,$tpl);
		}

		$this->compile_time = time();

		return $tpl;
	}

	private function replaceMagic($data)
	{
		$in = array();

		while(preg_match(self::$OTPL_ROOT_ALIAS_REG,$data,$in))
		{
			$data = str_replace($in[0],$this->otpl_root_data_ref . $in[1],$data);
		}

		while(preg_match(self::$OTPL_IMPORT_REG,$data,$in))
		{
			@list($found,$url) = $in;
			$txt = "";

			if( isset($in[2]) )
			{
				$txt = $this->import($url,$in[2]);
			} else {
				$txt = $this->import($url,null);
			}

			$data = str_replace($found,$txt,$data);
		}

		$data =  str_replace('@var','',$data);
		
		$data =  str_replace('@',self::$OTPL_PLUGINS_OBJ_REF,$data);

		return $data;
	}

	private function replaceJsObjectDot($data){
		$in = array();

		for( $i = 0 ; $i < count(self::$OTPL_REPLACE); $i++ )
		{
			while(preg_match(self::$OTPL_REPLACE[$i],$data,$in))
			{
				$txt = "";
				@list($found,$start,$key_name) = $in;

				if( !empty($found) )
				{
					if (preg_match(self::$OTPL_STR_KEY_NAME_REG,$key_name))
					{
						$key_name = "'$key_name'";
					}

					$txt .= ( $start === ']')? "]" : $this->otpl_root_data_ref;
					$txt .= "[$key_name]";
					$data = str_replace($found,$txt,$data);
				}
			}
		}

		return $data;
	}

	private function process($data)
	{
		$data = $this->replaceJsObjectDot($data);
		$data = $this->replaceMagic($data);

		if(preg_match(self::$OTPL_SCRIPT_REG,$data))
		{
			return "<?php $data ?>";
		}

		return "<?php echo ($data); ?>";
	}

	private function import($url,$data_str = null)
	{
		$root = __DIR__;

		if($this->src_path){

			$pinfos = pathinfo($this->src_path);
			$root = $pinfos['dirname']; 
		}

		$url = OPathResolver::resolve($root,$url);

		if (preg_match(self::$OTPL_FILE_EXT,$url))
		{
			return " OTplUtils::importExec('$url',$data_str) ";
		} else {
			return " OTplUtils::loadFile('$url') ";
		}
	}
}