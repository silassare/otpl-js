<?php

final class OTplUtils
{
	public static function loadFile($src)
	{
		if ( empty($src) || !file_exists( $src ) || !is_file( $src ) || !is_readable( $src ) )
		{
			throw new Exception("Unable to access file at : $src");
		}

		return file_get_contents($src);
	}

	public static function importExec($url,$data)
	{
		$obj = new OTpl();
		$import_url = $obj->parse($url,true)->runWith($data);
	}
}